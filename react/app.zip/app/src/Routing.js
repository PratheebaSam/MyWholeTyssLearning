import { BrowserRouter as Router, Link, Route, Routes } from "react-router-dom";

// import Header from "./components/component1/Header";
// import ReRender from "./components/component1/UseEffect";
import Useref from "./components/component1/Useref";
const routing = (
  <Router>
    <div>
      <Link to="/"></Link>
    </div>
    <div>
      <Routes>
        <Route path="/" component={Useref}></Route>
      </Routes>
    </div>
  </Router>
);

export default routing;
