import React, { useState, useEffect } from "react";

function ReRender() {
  const [count, setCount] = useState(1);
  useEffect(() => {
    document.title = `you clicked ${count} times`;
  });
  return (
    <div className="render">
      <button onClick={() => setCount(count + 1)}>clicked {count}</button>
    </div>
  );
}

export default ReRender;
