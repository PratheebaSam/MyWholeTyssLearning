//used for pointing the cursor in text field.
import React, { useEffect, useRef } from "react";

function Useref() {
  const input = useRef(null);
  useEffect(() => {
    input.current.focus();
  }, []);
  return (
    <div>
      <input ref={input} type="text" />
      {/* <input ref={input} type="password" /> */}
    </div>
  );
}

export default Useref;
