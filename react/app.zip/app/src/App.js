import React from "react";
import routing from "./Routing";

function App() {
  return <div className="App">{routing}</div>;
}

export default App;
