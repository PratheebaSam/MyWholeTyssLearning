package com.ms.registration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ms.jdbcData.UserData;

/**
 * Servlet implementation class SignUp
 */
//@WebServlet("/register")
public class UserSignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserSignUp() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("userName");
		String userPhoneNumber = request.getParameter("userPhoneNumber");
		String userEmail = request.getParameter("userEmail");
		String userPassword = request.getParameter("userPassword");

		UserData userData = new UserData();
		userData.setUserName(userName);
		userData.setPhoneNumber(userPhoneNumber);
		userData.setUserEmail(userEmail);
		userData.setUserPassword(userPassword);

		System.out.println(userData);
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("userData");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		manager.persist(userData);
		transaction.begin();
		transaction.commit();

		PrintWriter writer = response.getWriter();
		writer.println("<html><h3>Welcome " + userName + "</h3></html>");
	}

}
